package com.infy.dao;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.ParameterMetadata;
import org.hibernate.query.Query;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



//import com.infy.entity.UserDetailsEntity;
import com.infy.entity.UserEntity;
import com.infy.model.ModelPost;
import com.infy.model.User;


@Repository("dao")
public class etltestingDAOImpl implements etltestingDAO {

	@Autowired
	SessionFactory sessionFactory;	

	public Integer getDetails(ModelPost modelpost2){
		ModelPost modelpost1;String hql1;
		Query query;
		List<String> list2=new ArrayList<>();
		List<UserEntity> users=null;
		try{
			list2=this.getAllDetails(modelpost2);
		Session session = sessionFactory.getCurrentSession();
		//String userId="A";
		String tableName=list2.get(0);
		String firstCondition=list2.get(2);
		String columnName=list2.get(3);
		String firstClause=list2.get(4);
		String value=list2.get(5);
		String opera=list2.get(6);
		String secondClause=list2.get(9);
		String value1=list2.get(10);
		String columnName1=list2.get(8);
		System.out.println("ffffline42");
		if(!firstClause.equals("LIKE")){
		if(firstClause.equals("&gt"))
			{firstClause=">";}
		if(firstClause.equals("&lt"))
		{firstClause="<";}
		if(firstClause.equals("&gt="))
		{firstClause=">=";}
		if(firstClause.equals("&lt="))
		{firstClause="<=";}
		if(firstClause.equals("&gt"))
		{firstClause=">";}
		hql1 = "from "+tableName+" "+firstCondition+" "+columnName+" "+firstClause+" "+":keyword";
		//System.out.println("1");
		//System.out.println(hql1);
		query =session.createQuery(hql1);
		query.setParameter("keyword",Double.parseDouble(value));
		users=(List<UserEntity>)query.getResultList();}
		else
		{
			System.out.println(value);
			hql1 = "from "+tableName+" "+firstCondition+" "+columnName+" "+firstClause+" "+":keyword";
			query =session.createQuery(hql1);
			query.setParameter("keyword",value);
			users=(List<UserEntity>)query.getResultList();
		}
		if(opera.equals("And") || opera.equals("Or"))
		{
			//System.out.println("2nd clause");
			if(secondClause.equals("LIKE"))
			{
				//System.out.println("2nd clause number1");
				if(secondClause.equals("&gt"))
				{secondClause=">";}
				if(secondClause.equals("&lt"))
				{secondClause="<";}
				if(secondClause.equals("&gt="))
				{secondClause=">=";}
				if(secondClause.equals("&lt="))
				{secondClause="<=";}
				if(secondClause.equals("&gt"))
				{secondClause=">";}				
				hql1=hql1+" "+opera+" "+columnName1+" "+secondClause+" "+":keyword1";
				//System.out.println(hql1);
				query =session.createQuery(hql1);
				query.setParameter("keyword1",Double.parseDouble(value1));
				if(firstClause.equals("Like"))
					query.setParameter("keyword", value);
				if(!firstClause.equals("Like"))
					query.setParameter("keyword", Double.parseDouble(value));
				users=(List<UserEntity>)query.getResultList();
			}
			else
			{
				//System.out.println("2nd clause like");
				hql1=hql1+" "+opera+" "+columnName1+" "+secondClause+" "+":keyword1";
				//System.out.println(hql1);
				query =session.createQuery(hql1);
				query.setParameter("keyword1",value1);
				if(firstClause.equals("Like"))
					query.setParameter("keyword", value);
				if(!firstClause.equals("Like"))
					query.setParameter("keyword", Double.parseDouble(value));}
				users=(List<UserEntity>)query.getResultList();
			}
		return users.size();
	}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
		}
	public Integer targetTable(ModelPost modelpost5){
		ModelPost modelpost8;Query query;
		List<String> list1=new ArrayList<>();
		List<UserEntity> users=null;
		try{
			String hql1;
			list1=this.getAllDetails(modelpost5);
			String userId="A";
			String tableName=list1.get(1);
			String firstCondition=list1.get(2);
			String columnName=list1.get(3);
			String firstClause=list1.get(4);
			String value=list1.get(5);
			String opera=list1.get(6);
			String secondClause=list1.get(9);
			String value1=list1.get(10);
			String columnName1=list1.get(8);
			Session session = sessionFactory.getCurrentSession();
			//System.out.println("hhhh");
			//if(modelpost8.getOperator().equals("Or") || modelpost8.getOperator().equals("And"))
				//hql1="from "+tableName+" "+firstCondition+" "+columnName+" "+firstClause+" "+value+" "+opera+" "+columnName1+" "+secondClause+" "+value1;
			//else
			if(!firstClause.equals("LIKE"))
			{
				if(firstClause.equals("&gt"))
				{firstClause=">";}
				if(firstClause.equals("&lt"))
				{firstClause="<";}
				if(firstClause.equals("&gt="))
				{firstClause=">=";}
				if(firstClause.equals("&lt="))
				{firstClause="<=";}
				if(firstClause.equals("&gt"))
				{firstClause=">";}
				hql1 = "from "+tableName+" "+firstCondition+" "+columnName+" "+firstClause+" "+":keyword";
				query =session.createQuery(hql1);
				query.setParameter("keyword",Double.parseDouble(value));
				users=(List<UserEntity>)query.getResultList();
			}
			else
				{hql1 = "from "+tableName+" "+firstCondition+" "+columnName+" "+firstClause+" "+":keyword";
				//String hql = "from UserEntity where emailId like :keyword";
				query =session.createQuery(hql1);
				query.setParameter("keyword",value);
				users=(List<UserEntity>)query.getResultList();}
			
			
			
			if(opera.equals("And") || opera.equals("Or"))
			{
				//System.out.println("2nd clause");
				if(secondClause.equals("LIKE"))
				{
					//System.out.println("2nd clause number");
					if(secondClause.equals("&gt"))
					{secondClause=">";}
					if(secondClause.equals("&lt"))
					{secondClause="<";}
					if(secondClause.equals("&gt="))
					{secondClause=">=";}
					if(secondClause.equals("&lt="))
					{secondClause="<=";}
					if(secondClause.equals("&gt"))
					{secondClause=">";}				
					hql1=hql1+" "+opera+" "+columnName1+" "+secondClause+" "+":keyword1";
					//System.out.println(hql1);
					query =session.createQuery(hql1);
					query.setParameter("keyword1",Double.parseDouble(value1));
					if(firstClause.equals("Like"))
						query.setParameter("keyword", value);
					if(!firstClause.equals("Like"))
						query.setParameter("keyword", Double.parseDouble(value));
					users=(List<UserEntity>)query.getResultList();
				}
				else
				{
					//System.out.println("2nd clause like1111");
					hql1=hql1+" "+opera+" "+columnName1+" "+secondClause+" "+":keyword1";
					//System.out.println(hql1);
					query =session.createQuery(hql1);
					query.setParameter("keyword1",value1);
					if(firstClause.equals("Like"))
						query.setParameter("keyword", value);
					if(!firstClause.equals("Like"))
						query.setParameter("keyword", Double.parseDouble(value));}
					users=(List<UserEntity>)query.getResultList();
				}
			return users.size();
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	public List<User> getAllUsers() throws Exception{
		Session session = sessionFactory.getCurrentSession();
		List<User> allUsers = new ArrayList<>();
		Query qry = session.createQuery("select User from UserEntity User");
		@SuppressWarnings("unchecked")
		List<UserEntity> allUserEntities = qry.list();
		for(UserEntity ele:allUserEntities){
			User u=new User();
			u.setFirstName(ele.getFirstName());
			u.setSecondName(ele.getSecondName());
			u.setEmailId(ele.getEmailId());
			u.setDateOfJoin(ele.getDateOfJoin());
			u.setSalary(ele.getSalary());
			allUsers.add(u);
		}
		return allUsers;
		
	}
	public User getByEmailId(String emailId) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		UserEntity userentity=(UserEntity)session.get(UserEntity.class,emailId);
		System.out.println(emailId);
		System.out.println(userentity.getFirstName());
		System.out.println(userentity.getSecondName());
		System.out.println(userentity.getSalary());
		System.out.println(userentity.getDateOfJoin());
		User user=new User();
		if(userentity!=null){
			user.setFirstName(userentity.getFirstName());
			user.setSecondName(userentity.getSecondName());
			user.setSalary(userentity.getSalary());
			user.setDateOfJoin(userentity.getDateOfJoin());
			
		}
		return user;		
	}
	public User addUser(User user) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		UserEntity us = new UserEntity();
		us.setFirstName(user.getFirstName());
		us.setSecondName(user.getSecondName());
		us.setEmailId(user.getEmailId());
		us.setDateOfJoin(user.getDateOfJoin());
		us.setSalary(user.getSalary());
		session.persist(us);
		return user;
	}
	public List<String> getAllDetails(ModelPost modelpost) throws Exception{
		ModelPost model=new ModelPost();
		model.setSource(modelpost.getSource());
		model.setDestination(modelpost.getDestination());
		model.setFirstcondition(modelpost.getFirstcondition());
		model.setFirstclause(modelpost.getFirstclause());
		model.setColumnName(modelpost.getColumnName());
		model.setValue1(modelpost.getValue1());
		model.setOperator(modelpost.getOperator());
		model.setSecondcondition(modelpost.getSecondcondition());
		model.setSecondclause(modelpost.getSecondclause());
		model.setValue2(modelpost.getValue2());
		model.setOperator(modelpost.getOperator());
		model.setColumnName1(modelpost.getColumnName1());
		model.setColumnSum(modelpost.getColumnSum());
		List<String> list=new ArrayList<>();
		list.add(model.getSource()); //0
		list.add(model.getDestination()); //1
		list.add(model.getFirstcondition()); //2
		list.add(model.getColumnName()); //3
		list.add(model.getFirstclause()); //4
		list.add(model.getValue1()); //5
		list.add(model.getOperator()); //6
		list.add(model.getSecondcondition());  //7
		list.add(model.getColumnName1()); //8
		list.add(model.getSecondclause()); //9
		list.add(model.getValue2()); //10
		list.add(model.getColumnSum()); //11
		return list;
	}




public Double ChecksumSource(ModelPost modelpost2){
	ModelPost modelpost1;String hql1;
	Query query;
	List<String> list2=new ArrayList<>();
	List<UserEntity> users=null;
	try{
		list2=this.getAllDetails(modelpost2);
	Session session = sessionFactory.getCurrentSession();
	//String userId="A";
	String tableName=list2.get(0);
	String firstCondition=list2.get(2);
	String columnName=list2.get(3);
	String firstClause=list2.get(4);
	String value=list2.get(5);
	String opera=list2.get(6);
	String secondClause=list2.get(9);
	String value1=list2.get(10);
	String columnName1=list2.get(8);
	String columnSum=list2.get(11);
	//System.out.println("ffff");
	if(!firstClause.equalsIgnoreCase("LIKE")){
	if(firstClause.equals("&gt"))
		{firstClause=">";}
	if(firstClause.equals("&lt"))
	{firstClause="<";}
	if(firstClause.equals("&gt="))
	{firstClause=">=";}
	if(firstClause.equals("&lt="))
	{firstClause="<=";}
	if(firstClause.equals("&gt"))
	{firstClause=">";}
	hql1 = "Select sum("+columnSum+") from "+tableName+" "+firstCondition+" "+columnName+" "+firstClause+" "+":keyword";
	//System.out.println("1");
	//System.out.println(hql1);
	query =session.createQuery(hql1);
	query.setParameter("keyword",Double.parseDouble(value));
	users=(List<UserEntity>)query.getResultList();}
	else
	{
		System.out.println(value);
		hql1 = "Select sum("+columnSum+") from "+tableName+" "+firstCondition+" "+columnName+" "+firstClause+" "+":keyword";
		query =session.createQuery(hql1);
		query.setParameter("keyword",value);
		users=(List<UserEntity>)query.getResultList();
	}
	if(opera.equalsIgnoreCase("And") || opera.equalsIgnoreCase("Or"))
	{
		//System.out.println("2nd clause");
		if(!secondClause.equalsIgnoreCase("LIKE"))
		{
			//System.out.println("2nd clause number1");
			if(secondClause.equals("&gt"))
			{secondClause=">";}
			if(secondClause.equals("&lt"))
			{secondClause="<";}
			if(secondClause.equals("&gt="))
			{secondClause=">=";}
			if(secondClause.equals("&lt="))
			{secondClause="<=";}
			if(secondClause.equals("&gt"))
			{secondClause=">";}				
			hql1=hql1+" "+opera+" "+columnName1+" "+secondClause+" "+":keyword1";
			//System.out.println(hql1);
			query =session.createQuery(hql1);
			query.setParameter("keyword1",Double.parseDouble(value1));
			if(firstClause.equals("Like"))
				query.setParameter("keyword", value);
			if(!firstClause.equals("Like"))
				query.setParameter("keyword", Double.parseDouble(value));
			users=(List<UserEntity>)query.getResultList();
		}
		else
		{
			//System.out.println("2nd clause like");
			hql1=hql1+" "+opera+" "+columnName1+" "+secondClause+" "+":keyword1";
			//System.out.println(hql1);
			query =session.createQuery(hql1);
			query.setParameter("keyword1",value1);
			if(firstClause.equalsIgnoreCase("Like"))
				query.setParameter("keyword", value);
			if(!firstClause.equalsIgnoreCase("Like"))
				query.setParameter("keyword", Double.parseDouble(value));}
			users=(List<UserEntity>)query.getResultList();
		}
	System.out.println("source");
	System.out.println(query.list().get(0));
	return (Double) query.list().get(0);
	}
	catch(Exception e){
		e.printStackTrace();
		return null;
	}
	}




public Double ChecksumTarget(ModelPost modelpost2){
	ModelPost modelpost1;String hql1;
	Query query;
	List<String> list2=new ArrayList<>();
	List<UserEntity> users=null;
	try{
		list2=this.getAllDetails(modelpost2);
	Session session = sessionFactory.getCurrentSession();
	//String userId="A";
	String tableName=list2.get(0);
	String firstCondition=list2.get(2);
	String columnName=list2.get(3);
	String firstClause=list2.get(4);
	String value=list2.get(5);
	String opera=list2.get(6);
	String secondClause=list2.get(9);
	String value1=list2.get(10);
	String columnName1=list2.get(8);
	String columnSum=list2.get(11);
	System.out.println("ffff111");
	System.out.println(firstClause);
	if(!firstClause.equalsIgnoreCase("LIKE")){
		System.out.println("inside like");
	if(firstClause.equals("&gt"))
		{firstClause=">";}
	if(firstClause.equals("&lt"))
	{firstClause="<";}
	if(firstClause.equals("&gt="))
	{firstClause=">=";}
	if(firstClause.equals("&lt="))
	{firstClause="<=";}
	if(firstClause.equals("&gt"))
	{firstClause=">";}
	hql1 = "Select sum("+columnSum+") from "+tableName+" "+firstCondition+" "+columnName+" "+firstClause+" "+":keyword";
	//System.out.println("1");
	//System.out.println(hql1);
	query =session.createQuery(hql1);
	query.setParameter("keyword",Double.parseDouble(value));
	users=(List<UserEntity>)query.getResultList();}
	else
	{
		System.out.println("inside number");
		//System.out.println(value);
		hql1 = "Select sum("+columnSum+") from "+tableName+" "+firstCondition+" "+columnName+" "+firstClause+" "+":keyword";
		query =session.createQuery(hql1);
		query.setParameter("keyword",value);
		users=(List<UserEntity>)query.getResultList();
	}
	if(opera.equalsIgnoreCase("And") || opera.equalsIgnoreCase("Or"))
	{
		//System.out.println("2nd clause");
		if(!secondClause.equalsIgnoreCase("LIKE"))
		{
			//System.out.println("2nd clause number1");
			if(secondClause.equals("&gt"))
			{secondClause=">";}
			if(secondClause.equals("&lt"))
			{secondClause="<";}
			if(secondClause.equals("&gt="))
			{secondClause=">=";}
			if(secondClause.equals("&lt="))
			{secondClause="<=";}
			if(secondClause.equals("&gt"))
			{secondClause=">";}				
			hql1=hql1+" "+opera+" "+columnName1+" "+secondClause+" "+":keyword1";
			//System.out.println(hql1);
			query =session.createQuery(hql1);
			query.setParameter("keyword1",Double.parseDouble(value1));
			if(firstClause.equals("Like"))
				query.setParameter("keyword", value);
			if(!firstClause.equals("Like"))
				query.setParameter("keyword", Double.parseDouble(value));
			users=(List<UserEntity>)query.getResultList();
			/*ParameterMetadata a = query.getParameterMetadata();
			System.out.println("******************");
			
			System.out.println(a.getNamedParameterNames())*/;
		}
		else
		{
			System.out.println("5555555555555");
			//System.out.println("2nd clause like");
			hql1=hql1+" "+opera+" "+columnName1+" "+secondClause+" "+":keyword1";
			//System.out.println(hql1);
			query =session.createQuery(hql1);
			query.setParameter("keyword1",value1);
			if(firstClause.equalsIgnoreCase("Like"))
				query.setParameter("keyword", value);
			if(!firstClause.equalsIgnoreCase("Like"))
				query.setParameter("keyword", Double.parseDouble(value));}
			users=(List<UserEntity>)query.getResultList();
			Set<String> keySet=null;
			
			/*Query query1=session.createSQLQuery("Select * from UserEntity"); 
			query.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE); 
			List<Map<String,Object>> aliasToValueMapList=query1.list();
			for (Map<String, Object> map : aliasToValueMapList)
			{
				keySet=map.keySet();		
			}
			System.out.println(keySet);*/
		}
	System.out.println("target");
	System.out.println(hql1);
	System.out.println(query.list().get(0));
	return (Double) query.list().get(0);
}
	catch(Exception e){
		e.printStackTrace();
		return null;
	}
	}
}