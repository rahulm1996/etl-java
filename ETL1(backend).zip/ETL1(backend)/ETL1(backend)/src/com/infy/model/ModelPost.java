package com.infy.model;

import java.util.ArrayList;
import java.util.List;

public class ModelPost {
	private String source;
	private String destination;
	private String firstcondition;
	private String firstclause;
	private String value1;
	private String operator;
	private String secondcondition;
	private Double sumSource;
	private Double sumTarget;
	private String secondclause;
	private String value2;
	private String columnName;
	public Double getSumSource() {
		return sumSource;
	}
	public void setSumSource(Double sumSource) {
		this.sumSource = sumSource;
	}
	public Double getSumTarget() {
		return sumTarget;
	}
	public void setSumTarget(Double sumTarget) {
		this.sumTarget = sumTarget;
	}
	private String columnName1;
	private String columnSum;
	private String message;
	private Integer count1;
	private Integer count2;
	
	
	
	public String getColumnSum() {
		return columnSum;
	}
	public void setColumnSum(String columnSum) {
		this.columnSum = columnSum;
	}
	public Integer getCount1() {
		return count1;
	}
	public void setCount1(Integer count1) {
		this.count1 = count1;
	}
	public Integer getCount2() {
		return count2;
	}
	public void setCount2(Integer count2) {
		this.count2 = count2;
	}
	public List<String> modelList=new ArrayList<>();
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getColumnName1() {
		return columnName1;
	}
	public void setColumnName1(String columnName1) {
		this.columnName1 = columnName1;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getFirstcondition() {
		return firstcondition;
	}
	public void setFirstcondition(String firstcondition) {
		this.firstcondition = firstcondition;
	}
	public String getFirstclause() {
		return firstclause;
	}
	public void setFirstclause(String firstclause) {
		this.firstclause = firstclause;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getSecondcondition() {
		return secondcondition;
	}
	public void setSecondcondition(String secondcondition) {
		this.secondcondition = secondcondition;
	}
	public String getSecondclause() {
		return secondclause;
	}
	public void setSecondclause(String secondclause) {
		this.secondclause = secondclause;
	}
	public String getValue1() {
		return value1;
	}
	public void setValue1(String value1) {
		this.value1 = value1;
	}
	public String getValue2() {
		return value2;
	}
	public void setValue2(String value2) {
		this.value2 = value2;
	}
	
}
