package com.infy.model;

import java.time.LocalDate;

public class UserDetails {
	private String fullName;
	private String emaidId;
	private double salary;
	private LocalDate dateOfJoin;
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmaidId() {
		return emaidId;
	}
	public void setEmaidId(String emaidId) {
		this.emaidId = emaidId;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getDateOfJoin() {
		return dateOfJoin;
	}
	public void setDateOfJoin(LocalDate dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}
	
}
