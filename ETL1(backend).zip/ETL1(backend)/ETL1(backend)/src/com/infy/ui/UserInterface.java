package com.infy.ui;
import com.infy.model.ModelPost;
import com.infy.service.EtlTestingService;
import com.infy.service.EtlTestingServiceImpl;
import com.infy.utility.ContextFactory;

public class UserInterface {
	static EtlTestingService userService = (EtlTestingServiceImpl) ContextFactory
			.getContext().getBean("etltestingservice");

	public static void main(String[] args) throws Exception {
		ModelPost modelpost2=null;
		ModelPost modelpost5=null;
		Integer source=getDetails(modelpost2);
		Integer target=targetTable(modelpost5);
		if(source==target){
			System.out.println("The count testing is successfull");
			System.out.println("Source Table count is : " +source);
			System.out.println("Target Table count is : "+target);
		}
		else{
			System.out.println("The count testing is unsuccessfull");
			System.out.println("Source Table count is : " +source);
			System.out.println("Target Table count is : "+target);
		}
		/*Object sourceSalary=sourceTableSalary();
		Object targetSalary=targetTableSalary();
		if(sourceSalary.equals(targetSalary)){
			System.out.println("The checksum testing is successfull");
			System.out.println("Total Salary of Source Table is : " +sourceSalary);
			System.out.println("Total Salary of Target Table is : " +targetSalary);
		}
		else{
			System.out.println("The checksum testing is unsuccessfull");
			System.out.println("Total Salary of Source Table is : " +sourceSalary);
			System.out.println("Total Salary of Target Table is : " +targetSalary);
		}*/
		
	}
	
	private static Integer getDetails(ModelPost modelpost2) throws Exception {
		return userService.getDetails(modelpost2);
}
	private static Integer targetTable(ModelPost modelpost5) throws Exception {
		return userService.targetTable(modelpost5);
	}
/*	private static Object sourceTableSalary() throws Exception {
		return userService.sourceTableSalary();
	}
	private static Object targetTableSalary() throws Exception {
		return userService.targetTableSalary();
	}*/
	

}