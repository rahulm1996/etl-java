package com.infy.entity;
import java.time.LocalDate;
import java.util.Calendar;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NamedQuery;


@Entity

public class UserEntity {
                
                private String  firstName;
                
                private String secondName;
                
                @Id
                private String emailId;
                
                private double salarysss;
                
                
                private LocalDate dateOfJoin;

                public String getFirstName() {
                                return firstName;
                }

                public void setFirstName(String firstName) {
                                this.firstName = firstName;
                }

                public String getSecondName() {
                                return secondName;
                }

                public void setSecondName(String secondName) {
                                this.secondName = secondName;
                }

                public String getEmailId() {
                                return emailId;
                }

                public void setEmailId(String emailId) {
                                this.emailId = emailId;
                }

                public double getSalary() {
                                return salarysss;
                }
                
                public void setSalary(double salarysss) {
                                this.salarysss = salarysss;
                }

                public LocalDate getDateOfJoin() {
                                return dateOfJoin;
                }

                public void setDateOfJoin(LocalDate dateOfJoin) {
                                this.dateOfJoin = dateOfJoin;
                }
}
