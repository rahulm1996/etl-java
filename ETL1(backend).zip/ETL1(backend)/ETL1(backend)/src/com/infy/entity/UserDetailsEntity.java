package com.infy.entity;
import java.time.LocalDate;
import java.util.Calendar;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity

public class UserDetailsEntity {
                
                
                private String  fullName;
                
                @Id
                private String emailId;
                
                private double salarysss;
                
                
                private LocalDate dateOfJoin;

                public String getFullName() {
                                return fullName;
                }

                public void setFullName(String fullName) {
                                this.fullName = fullName;
                }

                public String getEmailId() {
                                return emailId;
                }

                public void setEmailId(String emailId) {
                                this.emailId = emailId;
                }

                public double getSalary() {
                                return salarysss;
                }

                public void setSalary(double salarysss) {
                                this.salarysss = salarysss;
                }

                public LocalDate getDateOfJoin() {
                                return dateOfJoin;
                }

                public void setDateOfJoin(LocalDate dateOfJoin) {
                                this.dateOfJoin = dateOfJoin;
                }
}

