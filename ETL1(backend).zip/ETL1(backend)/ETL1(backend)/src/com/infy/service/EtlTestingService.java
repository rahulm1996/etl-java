package com.infy.service;

import java.util.List;

import com.infy.entity.UserEntity;
import com.infy.model.ModelPost;
import com.infy.model.User;

public interface EtlTestingService
{
	public Integer  getDetails(ModelPost modelpost2) throws Exception;
	public Integer targetTable(ModelPost modelpost5) throws Exception;
	/*public Object sourceTableSalary() throws Exception;
	public Object targetTableSalary() throws Exception;*/
	public List<User> getAllUsers() throws Exception;
	public User getByEmailId(String emailId) throws Exception;
	public User addUser(User user) throws Exception;
	public List<String> getAllDetails(ModelPost modelpost) throws Exception;
	public Double  ChecksumSource(ModelPost modelpost2) throws Exception;
	public Double  ChecksumTarget(ModelPost modelpost2) throws Exception;
}
