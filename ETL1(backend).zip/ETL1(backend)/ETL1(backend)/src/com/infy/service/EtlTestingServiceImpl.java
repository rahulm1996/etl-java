package com.infy.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.etltestingDAO;
import com.infy.entity.UserEntity;
import com.infy.model.ModelPost;
import com.infy.model.User;



@Service("etltestingservice")
@Transactional(readOnly = true)
public  class EtlTestingServiceImpl implements EtlTestingService {

	@Autowired
	private etltestingDAO dao;

	public Integer  getDetails(ModelPost modelpost2) throws Exception{
		return dao.getDetails(modelpost2);
	}

	public Integer targetTable(ModelPost modelpost5) throws Exception{
		return dao.targetTable(modelpost5);
	}
	public Double  ChecksumSource(ModelPost modelpost2) throws Exception{
		return dao.ChecksumSource(modelpost2);
	}

	public Double  ChecksumTarget(ModelPost modelpost2) throws Exception{
		return dao.ChecksumTarget(modelpost2);
	}

	/*public Object sourceTableSalary() throws Exception{
		return dao.sourceTableSalary();
	}
	public Object targetTableSalary() throws Exception{
		return dao.targetTableSalary();
	}*/
	public List<User> getAllUsers() throws Exception{
		List<User> allUsers=new ArrayList<>();
		allUsers=dao.getAllUsers();
		if(allUsers.size()<=0)
			throw new Exception("List is empty for getAllUsers");
		else
			return allUsers;
	}
	public User getByEmailId(String emailId) throws Exception{
		User user=dao.getByEmailId(emailId);
		if(user!=null)
			return user;
		else
			throw new Exception("List is empty for getByEmailId");
	}
	public User addUser(User user) throws Exception{
		User us=dao.addUser(user);
		if(us==null)
			throw new Exception("No User added");
		return us;
	}
	public List<String> getAllDetails(ModelPost modelpost) throws Exception{
		List<String> list3=dao.getAllDetails(modelpost);
		if(list3==null)
			throw new Exception("No Detials Added");
		return list3;
	}
}

