package com.infy.api;
import java.util.ArrayList;
import java.util.List;

import org.springframework.core.env.Environment;
//import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.ModelPost;
import com.infy.model.User;
import com.infy.service.EtlTestingService;
import com.infy.service.EtlTestingServiceImpl;
import com.infy.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping(value="TestingApi")
public class TestingApi {
      
      //private EtlTestingService etlTestingService;
      @RequestMapping(method=RequestMethod.GET, value="getTesting")
     public ResponseEntity<List<User>> getAllUsers(){
    	  //Environment environment= ContextFactory.getContext().getEnvironment();
  		ResponseEntity<List<User>> responseEntity=null;
  		List<User> allUsers=new ArrayList<User>();
  		EtlTestingService etltestingservice=(EtlTestingService)ContextFactory.getContext().getBean(EtlTestingServiceImpl.class);
		try {
			allUsers=etltestingservice.getAllUsers();
			responseEntity = new ResponseEntity<>(allUsers,HttpStatus.OK);

		} 
		catch(Exception exception) {
				//String errorMessage = environment.getProperty(exception.getMessage());
				User user = new User();			
				allUsers.add(user);			
				responseEntity = new ResponseEntity<>(allUsers,HttpStatus.BAD_REQUEST);
      }
		return responseEntity;
}
      
      @RequestMapping(method=RequestMethod.GET,value="getTestingbyemailId/{emailId}")
      public ResponseEntity<User> getByEmailId(@PathVariable("emailId") String emailId){
    	  ResponseEntity<User> responseEntity=null;
    	  User returnUser = new User();
    	  EtlTestingService etltestingservice= (EtlTestingService) ContextFactory.getContext().getBean(EtlTestingServiceImpl.class);
  		try {
  			returnUser=etltestingservice.getByEmailId(emailId);
  			responseEntity = new ResponseEntity<User>(returnUser,HttpStatus.OK);

  		}
  		catch(Exception exception) {
  			//String errorMessage = environment.getProperty(exception.getMessage());
  			User returnUser1 = new User();
  			responseEntity = new ResponseEntity<User>(returnUser1,HttpStatus.BAD_REQUEST);
  		}
  		return responseEntity;
      }
      
      
      @RequestMapping(method=RequestMethod.POST, value="getCount")
      public ResponseEntity<ModelPost> getCount(@RequestBody ModelPost modelpost4){
    	  String result= null;
    	  Integer a,b;
    	  ModelPost post= new ModelPost();
   		ResponseEntity<ModelPost> responseEntity=null;
   		EtlTestingService etltestingservice=(EtlTestingService)ContextFactory.getContext().getBean(EtlTestingServiceImpl.class);
   		try {
   			a=etltestingservice.getDetails(modelpost4);
 			b=etltestingservice.targetTable(modelpost4);
 			if(a==b)
 				{result="Count testing is Successful";
 				System.out.println("hello");
 				System.out.println("count of target table is "+b);
 				System.out.println("count of source table is "+a);
 				
 				}
 			else
 				{result="Count testing is Unsuccessful";
 				System.out.println("hi");
 				System.out.println("count of target table is "+b);
 				System.out.println("count of source table is "+a);
 				}
 			post.setMessage(result);
 			post.setCount1(a);
 			post.setCount2(b);
 			System.out.println(post.getMessage());
 			responseEntity = new ResponseEntity<ModelPost>(post,HttpStatus.OK);
 		} 
 		catch(Exception exception) {		
 			responseEntity = new ResponseEntity<ModelPost>(post,HttpStatus.BAD_REQUEST);
       }
 		return responseEntity;
 		
 }
      
      @RequestMapping(method=RequestMethod.POST, value="fetchDetail")
  	public ResponseEntity<User> fetchDetail(@RequestBody ModelPost modelpost)
  	{
  		User u= new User();
  		try
  		{
  			System.out.println("here");
  			EtlTestingService service=(EtlTestingService) ContextFactory.getContext().getBean(EtlTestingServiceImpl.class);
  			
  			return new ResponseEntity<User>(u,HttpStatus.OK);
  	}
  	catch(Exception e)
  		{
  		System.out.println("in catch");
  		Environment environment = ContextFactory.getContext().getEnvironment();
  		//u.setMessage(environment.getProperty("Service.INVALID_AADHAR_NUMBER"));
  		return new ResponseEntity<User>(u,HttpStatus.BAD_REQUEST);
  		}
  	}

 		
  		@RequestMapping(method=RequestMethod.POST, value="UserAdd1")
  		public ResponseEntity<ModelPost> addModel(@RequestBody ModelPost modelpost){
  			ResponseEntity<ModelPost> responseEntity=null;
  			List<String> returnAddedModelPost ;
  			ModelPost obj=new ModelPost();
  			EtlTestingService etltestingservice=(EtlTestingService)ContextFactory.getContext().getBean(EtlTestingServiceImpl.class);
  			try{
  				returnAddedModelPost=etltestingservice.getAllDetails(modelpost);
  				obj.modelList=returnAddedModelPost;
  				//responseEntity = new ResponseEntity<ModelPost>(obj.modelList,HttpStatus.OK);
  			}
  			catch(Exception e){
  				ModelPost returnAddedModelPost1=new ModelPost();
  				responseEntity = new ResponseEntity<ModelPost>(returnAddedModelPost1,HttpStatus.BAD_REQUEST);
  			}
  			return responseEntity;
  		}
  		
  		
  		
  		
  		
  		@RequestMapping(method=RequestMethod.POST, value="checksum")
        public ResponseEntity<ModelPost> checksum(@RequestBody ModelPost modelpost9){
      	  String result= null;
      	  Double a,b;
      	  ModelPost post= new ModelPost();
     		ResponseEntity<ModelPost> responseEntity=null;
     		EtlTestingService etltestingservice=(EtlTestingService)ContextFactory.getContext().getBean(EtlTestingServiceImpl.class);
     		try {
     			a=etltestingservice.ChecksumSource(modelpost9);
     			b=etltestingservice.ChecksumTarget(modelpost9);
     			if(a.equals(b))
   				{
     				//System.out.println("in correct api");
     				result="Checksum testing is Successful";
     				//System.out.println("hello");
     				System.out.println("sum of target table is "+b);
     				System.out.println("sum of source table is "+a);
   				}
     			else
   				{
     				//System.out.println("in incorrect api");
     				result="Checksum testing is Unsuccessful";
     				//System.out.println("hi");
     				System.out.println("sum of target table is "+b);
     				System.out.println("sum of source table is "+a);
   				}
     			post.setMessage(result);
     			post.setSumSource(a);
     			post.setSumTarget(b);
     			System.out.println(post.getMessage());
     			responseEntity = new ResponseEntity<ModelPost>(post,HttpStatus.OK);
     		} 
   		catch(Exception exception) {		
   			responseEntity = new ResponseEntity<ModelPost>(post,HttpStatus.BAD_REQUEST);
         }
   		return responseEntity;
   		
   }
  		
      
}
