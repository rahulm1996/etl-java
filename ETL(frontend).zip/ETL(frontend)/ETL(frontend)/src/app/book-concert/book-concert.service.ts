import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class BookConcertService {

  constructor(private http: Http) { }

  book(data){
    return this.http.post("http://localhost:8766/ETL1/TestingApi/getCount", data)
      .toPromise()
      .then(resp => resp.json())
      .catch(this.errorHandler);
  }
  private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }

}  