import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'genreType'})
export class SuccessMessagePipe implements PipeTransform {
  transform(value: string): string {
    let genre;
    if (value=="BM"){
      genre= "Black Metal";
    }
    else if(value=="MM"){
      genre= "Metal";
    }
    else if(value=="HR"){
      genre= "Hard Rock";
    }
    else if(value=="BB"){
      genre= "Blues"; 
    }
    else if(value=="SU"){
      genre= "Sufi";
    }
    return genre;
  }

}