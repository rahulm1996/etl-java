import { AbstractControl } from "@angular/forms";

export class DateValidator {
    static checkDate(date: AbstractControl) {
        let value = new Date(date.value);
        var d=new Date();
        
        if (d.getTime()<value.getTime()) {   
            return null;
        }
        else if(d.getTime()>=value.getTime()) {
            return { "checkDate": true };
        }
        return null;
        
    }

}