import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { BookConcertService } from './book-concert.service';


@Component({
  selector: 'app-book-concert',
  templateUrl: './book-concert.component.html',
  styleUrls: ['./book-concert.component.css']
})
export class BookConcertComponent implements OnInit {

  errorMessage: any;
  bookconcert=null;
  generateQuery:boolean=false;
  executeQuery:boolean=false;
  successMessage: any;
  count1:any;
  count2:any;
  bookingForm: FormGroup;
  var1:boolean=false;
  var2:boolean=false;
  constructor(private fb: FormBuilder, private bookConcertService: BookConcertService) { }

  book() {
    alert("It's Working")
    this.generateQuery=!this.generateQuery;
    console.log("asdf")
    this.bookConcertService.book(this.bookingForm.value)
    .then((response) => {this.successMessage=response.message
      this.count1=response.count1
      this.count2=response.count2
      console.log(response.count1)
      console.log(response.message)}
    )
    .catch(error =>         
      this.errorMessage = error.message)
  }
  checking(){
    this.var1=!this.var1;
    this.var2=false;
  }
  checkOn(){
    this.var2=!this.var2;
    this.var1=false;
  }
  ngOnInit() {
    
    this.bookingForm = this.fb.group({
      source: ['', [Validators.required,Validators.pattern("(UserEntity|UserDetailsEntity)")]],
      destination: ['', [Validators.required,Validators.pattern("(UserEntity|UserDetailsEntity)")]],
      firstcondition: ['', [Validators.required]],
      columnName: ['', [Validators.required,Validators.pattern("(fullName|emailId|salarysss|dateOfJoin|firstName|secondName)")]],
      columnName1: ['', [Validators.required,Validators.pattern("(fullName|emailId|salarysss|dateOfJoin|firstName|secondName)")]],
      operator: ['', [Validators.required]],
      secondcondition:['', [Validators.required]],
      firstclause:['', [Validators.required]],
      secondclause:['', [Validators.required]],
      value1:['', [Validators.required]],
      value2:['', [Validators.required]]
    });
  }
}   