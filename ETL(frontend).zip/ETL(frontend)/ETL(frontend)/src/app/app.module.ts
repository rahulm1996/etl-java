import { BookConcertService } from './book-concert/book-concert.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookConcertComponent } from './book-concert/book-concert.component';
import { HttpModule } from "@angular/http";
import { SuccessMessagePipe } from "./book-concert/genreType.pipe";
import { ChecksumComponent } from './checksum/checksum.component';
import { ChecksumService } from './checksum/checksum.service';

@NgModule({
  declarations: [
    AppComponent,
    BookConcertComponent,
    SuccessMessagePipe,
    ChecksumComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule
  ],
  providers: [BookConcertService,ChecksumService],
  bootstrap: [AppComponent]
})
export class AppModule { }
