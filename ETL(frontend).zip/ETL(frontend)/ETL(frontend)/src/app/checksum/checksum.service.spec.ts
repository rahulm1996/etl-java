import { TestBed, inject } from '@angular/core/testing';

import { ChecksumService } from './checksum.service';

describe('ChecksumService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ChecksumService]
    });
  });

  it('should be created', inject([ChecksumService], (service: ChecksumService) => {
    expect(service).toBeTruthy();
  }));
});
