import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class ChecksumService {

  constructor(private http: Http) { }

  book1(data){
    return this.http.post("http://localhost:8766/ETL1/TestingApi/checksum", data)
      .toPromise()
      .then(response => response.json())
      .catch(this.errorHandler);
  }
  private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }

} 


