import { Component, OnInit } from '@angular/core';
import { FormGroup,Validators,FormBuilder } from '@angular/forms';
import { ChecksumService } from './checksum.service';

@Component({
  selector: 'app-checksum',
  templateUrl: './checksum.component.html',
  styleUrls: ['./checksum.component.css']
})
export class ChecksumComponent implements OnInit {

  errorMessage: any;
  generateQuery:boolean=false;
  executeQuery:boolean=false;
  successMessage: any;
  CheckCheck: FormGroup;
  var1:boolean=false;
  var2:boolean=false;
  sum1:any;
  sum2:any;
  constructor(private fb: FormBuilder, private checksumserv: ChecksumService) { }

  book1() {
    
    this.generateQuery=!this.generateQuery;
    console.log("asdf")
    this.checksumserv.book1(this.CheckCheck.value)
    .then((response) => {this.successMessage=response.message
      this.sum1=response.sumSource
      this.sum2=response.sumTarget
      console.log(response.count1)
      console.log(response.message)}
    )
    .catch(error =>         
      this.errorMessage = error.message)
  }
  
  checking(){
    this.var1=!this.var1;
    this.var2=false;
  }
  checkOn(){
    this.var2=!this.var2;
    this.var1=false;
  }
  ngOnInit() {

      this.CheckCheck = this.fb.group({
      source: ['', [Validators.required,Validators.pattern("(UserEntity|UserDetailsEntity)")]],
      destination: ['', [Validators.required,Validators.pattern("(UserEntity|UserDetailsEntity)")]],
      columnSum:['',[Validators.required,Validators.pattern("(salarysss)")]],
      firstcondition: ['', [Validators.required]],
      columnName: ['', [Validators.required,Validators.pattern("(fullName|emailId|salarysss|dateOfJoin|firstName|secondName)")]],
      columnName1: ['', [Validators.required,Validators.pattern("(fullName|emailId|salarysss|dateOfJoin|firstName|secondName)")]],
      operator: ['', [Validators.required]],
      secondcondition:['', [Validators.required]],
      firstclause:['', [Validators.required]],
      secondclause:['', [Validators.required]],
      value1:['', [Validators.required]],
      value2:['', [Validators.required]]
    });
  }

}
